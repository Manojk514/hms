// ===== MOCK DATA =====
const mockAppointments = [
  {
    id: 'APT001',
    time: '09:00 AM',
    duration: '30 min',
    patientName: 'Rajesh Kumar',
    age: 45,
    gender: 'Male',
    phone: '+91 9876543210',
    reason: 'Chest pain and breathing difficulty',
    status: 'pending'
  },
  {
    id: 'APT002',
    time: '09:30 AM',
    duration: '30 min',
    patientName: 'Priya Sharma',
    age: 32,
    gender: 'Female',
    phone: '+91 9876543211',
    reason: 'Regular cardiac checkup',
    status: 'completed'
  },
  {
    id: 'APT003',
    time: '10:00 AM',
    duration: '30 min',
    patientName: 'Amit Patel',
    age: 58,
    gender: 'Male',
    phone: '+91 9876543212',
    reason: 'High blood pressure follow-up',
    status: 'in-progress'
  },
  {
    id: 'APT004',
    time: '10:30 AM',
    duration: '30 min',
    patientName: 'Sunita Devi',
    age: 41,
    gender: 'Female',
    phone: '+91 9876543213',
    reason: 'Heart palpitations',
    status: 'pending'
  },
  {
    id: 'APT005',
    time: '11:00 AM',
    duration: '30 min',
    patientName: 'Vikram Singh',
    age: 52,
    gender: 'Male',
    phone: '+91 9876543214',
    reason: 'Post-surgery follow-up',
    status: 'pending'
  },
  {
    id: 'APT006',
    time: '11:30 AM',
    duration: '30 min',
    patientName: 'Kavita Joshi',
    age: 38,
    gender: 'Female',
    phone: '+91 9876543215',
    reason: 'Diabetes and heart health',
    status: 'pending'
  },
  {
    id: 'APT007',
    time: '02:00 PM',
    duration: '30 min',
    patientName: 'Ravi Verma',
    age: 47,
    gender: 'Male',
    phone: '+91 9876543216',
    reason: 'Cholesterol management',
    status: 'pending'
  },
  {
    id: 'APT008',
    time: '02:30 PM',
    duration: '30 min',
    patientName: 'Meera Gupta',
    age: 35,
    gender: 'Female',
    phone: '+91 9876543217',
    reason: 'Chest X-ray review',
    status: 'completed'
  }
];

// ===== INITIALIZATION =====
document.addEventListener('DOMContentLoaded', function() {
  // Load doctor name from localStorage
  const doctorName = localStorage.getItem('doctorName') || 'Doctor';
  document.getElementById('doctorName').textContent = doctorName.replace('Dr. ', '');
  
  loadDashboardData();
  displayCurrentDate();
  loadTodaySchedule();
});

// ===== DISPLAY CURRENT DATE =====
function displayCurrentDate() {
  const dateElement = document.getElementById('currentDate');
  const today = new Date();
  const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
  dateElement.textContent = today.toLocaleDateString('en-US', options);
}

// ===== LOAD DASHBOARD DATA =====
function loadDashboardData() {
  // Calculate statistics from mock data
  const totalAppointments = mockAppointments.length;
  const completedCount = mockAppointments.filter(apt => apt.status === 'completed').length;
  const pendingFollowups = mockAppointments.filter(apt => apt.reason.toLowerCase().includes('follow-up')).length;
  
  // Update dashboard cards
  document.getElementById('todayAppointments').textContent = totalAppointments;
  document.getElementById('completedConsultations').textContent = completedCount;
  document.getElementById('pendingFollowups').textContent = pendingFollowups;
  document.getElementById('totalPatients').textContent = '156'; // Static for now
}

// ===== LOAD TODAY'S SCHEDULE =====
function loadTodaySchedule() {
  const container = document.getElementById('scheduleContainer');
  
  if (mockAppointments.length === 0) {
    container.innerHTML = `
      <div class="empty-state">
        <div class="icon">📅</div>
        <h3>No Appointments Today</h3>
        <p>You have no scheduled appointments for today.</p>
      </div>
    `;
    return;
  }
  
  container.innerHTML = '';
  
  mockAppointments.forEach(appointment => {
    const scheduleItem = document.createElement('div');
    scheduleItem.className = 'schedule-item';
    
    scheduleItem.innerHTML = `
      <div class="schedule-time">
        <div class="time">${appointment.time}</div>
        <div class="duration">${appointment.duration}</div>
      </div>
      
      <div class="schedule-details">
        <div class="patient-name">${appointment.patientName}</div>
        <div class="patient-info">${appointment.age} years • ${appointment.gender} • ${appointment.phone}</div>
        <div class="reason">${appointment.reason}</div>
      </div>
      
      <div class="schedule-actions">
        <span class="status-badge ${appointment.status}">${appointment.status.replace('-', ' ')}</span>
        ${appointment.status === 'pending' ? 
          `<button class="btn-start" onclick="startConsultation('${appointment.id}')">Start</button>` : 
          appointment.status === 'in-progress' ?
          `<button class="btn-start" onclick="continueConsultation('${appointment.id}')">Continue</button>` :
          ''
        }
      </div>
    `;
    
    container.appendChild(scheduleItem);
  });
}

// ===== START CONSULTATION =====
function startConsultation(appointmentId) {
  // Navigate to appointments page with this appointment selected
  localStorage.setItem('selectedAppointment', appointmentId);
  location.href = 'doctor_appointments.html';
}

// ===== CONTINUE CONSULTATION =====
function continueConsultation(appointmentId) {
  localStorage.setItem('selectedAppointment', appointmentId);
  location.href = 'doctor_appointments.html';
}

// ===== REFRESH SCHEDULE =====
function refreshSchedule() {
  loadTodaySchedule();
  loadDashboardData();
  
  // Show refresh feedback
  const btn = document.querySelector('.btn-refresh');
  const originalText = btn.textContent;
  btn.textContent = '✓ Refreshed';
  btn.style.background = '#dcfce7';
  btn.style.color = '#166534';
  
  setTimeout(() => {
    btn.textContent = originalText;
    btn.style.background = '';
    btn.style.color = '';
  }, 2000);
}

// ===== VIEW PENDING FOLLOW-UPS =====
function viewPendingFollowups() {
  localStorage.setItem('filterStatus', 'follow-up');
  location.href = 'doctor_appointments.html';
}

// ===== VIEW PATIENT HISTORY =====
function viewPatientHistory() {
  // Navigate to appointments page where doctors can select patients to view history
  location.href = 'doctor_appointments.html';
}

// ===== LOGOUT =====
function logout() {
  if (confirm('Are you sure you want to logout?')) {
    location.href = 'doctor_portal.html';
  }
}
