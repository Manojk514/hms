// ===== MOCK DOCTOR DATA =====
const doctorProfile = {
  id: 'DOC001',
  name: 'Dr. Rajesh Sharma',
  specialization: 'Cardiology',
  qualification: 'MBBS, MD (Cardiology)',
  experience: 15,
  licenseNumber: 'MCI-12345',
  joiningDate: '01 Jan 2020',
  email: 'dr.rajesh@itivatmed.com',
  phone: '+91 9876543210',
  emergencyContact: '+91 9876543211',
  address: '123 Medical Street, Hyderabad',
  stats: {
    totalPatients: 156,
    consultations: 1234,
    successRate: 98,
    rating: 4.8
  }
};

// ===== INITIALIZATION =====
document.addEventListener('DOMContentLoaded', function() {
  loadDoctorProfile();
});

// ===== LOAD DOCTOR PROFILE =====
function loadDoctorProfile() {
  // Load from localStorage if available
  const storedName = localStorage.getItem('doctorName');
  const storedId = localStorage.getItem('doctorId');
  
  if (storedName) {
    doctorProfile.name = storedName;
    document.getElementById('doctorName').textContent = storedName;
    document.getElementById('fullName').textContent = storedName;
    document.getElementById('editFullName').value = storedName;
    
    // Set avatar initials
    const initials = storedName.split(' ').map(n => n[0]).join('').substring(0, 2);
    document.getElementById('avatarInitials').textContent = initials;
  }
  
  if (storedId) {
    doctorProfile.id = storedId;
    document.getElementById('doctorId').textContent = storedId;
  }
  
  // Load other profile data
  document.getElementById('specialization').textContent = doctorProfile.specialization;
  document.getElementById('qualification').textContent = doctorProfile.qualification;
  document.getElementById('experience').textContent = `${doctorProfile.experience} years`;
  document.getElementById('licenseNumber').textContent = doctorProfile.licenseNumber;
  document.getElementById('joiningDate').textContent = doctorProfile.joiningDate;
  document.getElementById('email').textContent = doctorProfile.email;
  document.getElementById('phone').textContent = doctorProfile.phone;
  document.getElementById('emergencyContact').textContent = doctorProfile.emergencyContact;
  document.getElementById('address').textContent = doctorProfile.address;
}

// ===== TOGGLE EDIT MODE =====
function toggleEdit(section) {
  const editForm = document.getElementById(`${section}EditForm`);
  const infoGrid = editForm.previousElementSibling;
  
  if (editForm.style.display === 'none') {
    editForm.style.display = 'block';
    infoGrid.style.display = 'none';
  } else {
    editForm.style.display = 'none';
    infoGrid.style.display = 'grid';
  }
}

function cancelEdit(section) {
  toggleEdit(section);
}

// ===== SAVE PERSONAL INFO =====
function savePersonalInfo() {
  const name = document.getElementById('editFullName').value.trim();
  const specialization = document.getElementById('editSpecialization').value.trim();
  const qualification = document.getElementById('editQualification').value.trim();
  const experience = document.getElementById('editExperience').value;
  
  if (!name || !specialization || !qualification || !experience) {
    alert('Please fill all required fields');
    return;
  }
  
  // Update profile data
  doctorProfile.name = name;
  doctorProfile.specialization = specialization;
  doctorProfile.qualification = qualification;
  doctorProfile.experience = parseInt(experience);
  
  // Update display
  document.getElementById('doctorName').textContent = name;
  document.getElementById('fullName').textContent = name;
  document.getElementById('specialization').textContent = specialization;
  document.getElementById('qualification').textContent = qualification;
  document.getElementById('experience').textContent = `${experience} years`;
  
  // Update avatar initials
  const initials = name.split(' ').map(n => n[0]).join('').substring(0, 2);
  document.getElementById('avatarInitials').textContent = initials;
  
  // Save to localStorage
  localStorage.setItem('doctorName', name);
  
  // Close edit form
  toggleEdit('personal');
  
  alert('✓ Personal information updated successfully!');
}

// ===== SAVE CONTACT INFO =====
function saveContactInfo() {
  const phone = document.getElementById('editPhone').value.trim();
  const emergencyContact = document.getElementById('editEmergencyContact').value.trim();
  const address = document.getElementById('editAddress').value.trim();
  
  if (!phone) {
    alert('Phone number is required');
    return;
  }
  
  // Validate phone number format
  const phoneRegex = /^\+?[\d\s-]{10,}$/;
  if (!phoneRegex.test(phone)) {
    alert('Please enter a valid phone number');
    return;
  }
  
  // Update profile data
  doctorProfile.phone = phone;
  doctorProfile.emergencyContact = emergencyContact;
  doctorProfile.address = address;
  
  // Update display
  document.getElementById('phone').textContent = phone;
  document.getElementById('emergencyContact').textContent = emergencyContact || 'Not provided';
  document.getElementById('address').textContent = address || 'Not provided';
  
  // Close edit form
  toggleEdit('contact');
  
  alert('✓ Contact information updated successfully!');
}

// ===== CHANGE PASSWORD =====
function changePassword() {
  const currentPassword = document.getElementById('currentPassword').value;
  const newPassword = document.getElementById('newPassword').value;
  const confirmPassword = document.getElementById('confirmPassword').value;
  
  // Validate inputs
  if (!currentPassword || !newPassword || !confirmPassword) {
    alert('Please fill all password fields');
    return;
  }
  
  if (newPassword.length < 6) {
    alert('New password must be at least 6 characters long');
    return;
  }
  
  if (newPassword !== confirmPassword) {
    alert('New password and confirm password do not match');
    return;
  }
  
  if (currentPassword === newPassword) {
    alert('New password must be different from current password');
    return;
  }
  
  // In a real app, this would verify current password with backend
  // For now, we'll just show success message
  
  // Clear password fields
  document.getElementById('currentPassword').value = '';
  document.getElementById('newPassword').value = '';
  document.getElementById('confirmPassword').value = '';
  
  alert('✓ Password changed successfully!\n\nPlease use your new password for future logins.');
}

// ===== LOGOUT =====
function logout() {
  if (confirm('Are you sure you want to logout?')) {
    localStorage.removeItem('doctorName');
    localStorage.removeItem('doctorId');
    location.href = 'doctor_portal.html';
  }
}
