// ===== MOCK DATA =====
let appointments = [
  {
    id: 'APT001',
    time: '09:00 AM',
    patientName: 'Rajesh Kumar',
    age: 45,
    gender: 'Male',
    phone: '+91 9876543210',
    reason: 'Chest pain and breathing difficulty',
    status: 'pending',
    opNumber: 'OP12345'
  },
  {
    id: 'APT002',
    time: '09:30 AM',
    patientName: 'Priya Sharma',
    age: 32,
    gender: 'Female',
    phone: '+91 9876543211',
    reason: 'Regular cardiac checkup',
    status: 'completed',
    opNumber: 'OP12346'
  },
  {
    id: 'APT003',
    time: '10:00 AM',
    patientName: 'Amit Patel',
    age: 58,
    gender: 'Male',
    phone: '+91 9876543212',
    reason: 'High blood pressure follow-up',
    status: 'in-progress',
    opNumber: 'OP12347'
  },
  {
    id: 'APT004',
    time: '10:30 AM',
    patientName: 'Sunita Devi',
    age: 41,
    gender: 'Female',
    phone: '+91 9876543213',
    reason: 'Heart palpitations',
    status: 'pending',
    opNumber: 'OP12348'
  },
  {
    id: 'APT005',
    time: '11:00 AM',
    patientName: 'Vikram Singh',
    age: 52,
    gender: 'Male',
    phone: '+91 9876543214',
    reason: 'Post-surgery follow-up',
    status: 'pending',
    opNumber: 'OP12349'
  },
  {
    id: 'APT006',
    time: '11:30 AM',
    patientName: 'Kavita Joshi',
    age: 38,
    gender: 'Female',
    phone: '+91 9876543215',
    reason: 'Diabetes and heart health',
    status: 'pending',
    opNumber: 'OP12350'
  },
  {
    id: 'APT007',
    time: '02:00 PM',
    patientName: 'Ravi Verma',
    age: 47,
    gender: 'Male',
    phone: '+91 9876543216',
    reason: 'Cholesterol management',
    status: 'pending',
    opNumber: 'OP12351'
  },
  {
    id: 'APT008',
    time: '02:30 PM',
    patientName: 'Meera Gupta',
    age: 35,
    gender: 'Female',
    phone: '+91 9876543217',
    reason: 'Chest X-ray review',
    status: 'completed',
    opNumber: 'OP12352'
  },
  {
    id: 'APT009',
    time: '03:00 PM',
    patientName: 'Suresh Reddy',
    age: 62,
    gender: 'Male',
    phone: '+91 9876543218',
    reason: 'Hypertension consultation',
    status: 'pending',
    opNumber: 'OP12353'
  },
  {
    id: 'APT010',
    time: '03:30 PM',
    patientName: 'Anjali Nair',
    age: 29,
    gender: 'Female',
    phone: '+91 9876543219',
    reason: 'Pre-pregnancy cardiac screening',
    status: 'pending',
    opNumber: 'OP12354'
  },
  {
    id: 'APT011',
    time: '04:00 PM',
    patientName: 'Manoj Tiwari',
    age: 55,
    gender: 'Male',
    phone: '+91 9876543220',
    reason: 'ECG abnormality review',
    status: 'cancelled',
    opNumber: 'OP12355'
  },
  {
    id: 'APT012',
    time: '04:30 PM',
    patientName: 'Deepa Menon',
    age: 44,
    gender: 'Female',
    phone: '+91 9876543221',
    reason: 'Stress test follow-up',
    status: 'pending',
    opNumber: 'OP12356'
  }
];

let filteredAppointments = [...appointments];
let currentAppointmentId = null;

// ===== INITIALIZATION =====
document.addEventListener('DOMContentLoaded', function() {
  loadAppointments();
  updateCounts();
  
  // Check if there's a selected appointment from dashboard
  const selectedId = localStorage.getItem('selectedAppointment');
  if (selectedId) {
    localStorage.removeItem('selectedAppointment');
    viewPatientDetails(selectedId);
  }
  
  // Check if there's a filter from dashboard
  const filterStatus = localStorage.getItem('filterStatus');
  if (filterStatus) {
    localStorage.removeItem('filterStatus');
    if (filterStatus === 'follow-up') {
      document.getElementById('searchInput').value = 'follow-up';
      filterAppointments();
    }
  }
});

// ===== GET ACTION BUTTON BASED ON STATUS =====
function getActionButton(appointment) {
  switch(appointment.status) {
    case 'pending':
      return `
        <button class="btn-action primary" onclick="startConsultation('${appointment.id}')">
          🩺 Start Consultation
        </button>
        <button class="btn-action" onclick="viewPatientDetails('${appointment.id}')">
          👁️ View
        </button>
      `;
    
    case 'in-progress':
      return `
        <button class="btn-action success" onclick="continueConsultation('${appointment.id}')">
          ▶️ Continue Consultation
        </button>
        <button class="btn-action" onclick="viewPatientDetails('${appointment.id}')">
          👁️ View
        </button>
      `;
    
    case 'completed':
      return `
        <button class="btn-action" onclick="viewPatientDetails('${appointment.id}')">
          📋 View Details
        </button>
      `;
    
    case 'cancelled':
      return `
        <button class="btn-action" onclick="viewPatientDetails('${appointment.id}')">
          👁️ View
        </button>
      `;
    
    default:
      return `
        <button class="btn-action" onclick="viewPatientDetails('${appointment.id}')">
          👁️ View
        </button>
      `;
  }
}

// ===== CONTINUE CONSULTATION =====
function continueConsultation(appointmentId) {
  startConsultation(appointmentId);
}

// ===== LOAD APPOINTMENTS =====
function loadAppointments() {
  const tbody = document.getElementById('appointmentsBody');
  
  if (filteredAppointments.length === 0) {
    tbody.innerHTML = `
      <tr>
        <td colspan="8">
          <div class="empty-state">
            <div class="icon">📋</div>
            <h3>No Appointments Found</h3>
            <p>No appointments match your search criteria.</p>
          </div>
        </td>
      </tr>
    `;
    return;
  }
  
  tbody.innerHTML = '';
  
  filteredAppointments.forEach(appointment => {
    const row = document.createElement('tr');
    
    // Add highlight class for today's appointments (all are today in this mock)
    row.className = 'appointment-row';
    
    row.innerHTML = `
      <td><strong>${appointment.time}</strong></td>
      <td><strong>${appointment.patientName}</strong></td>
      <td>${appointment.age}</td>
      <td>${appointment.gender}</td>
      <td>${appointment.phone}</td>
      <td>${appointment.reason}</td>
      <td>
        <span class="status-badge ${appointment.status}">
          ${getStatusText(appointment.status)}
        </span>
      </td>
      <td>
        <div class="action-buttons">
          ${getActionButton(appointment)}
        </div>
      </td>
    `;
    
    tbody.appendChild(row);
  });
}

// ===== GET STATUS TEXT WITH ICONS =====
function getStatusText(status) {
  switch(status) {
    case 'pending':
      return '⏳ Pending';
    case 'in-progress':
      return '🔄 In Progress';
    case 'completed':
      return '✅ Completed';
    case 'cancelled':
      return '❌ Cancelled';
    default:
      return status.replace('-', ' ');
  }
}

// ===== UPDATE COUNTS =====
function updateCounts() {
  const total = filteredAppointments.length;
  const pending = filteredAppointments.filter(apt => apt.status === 'pending').length;
  const completed = filteredAppointments.filter(apt => apt.status === 'completed').length;
  
  document.getElementById('totalCount').textContent = total;
  document.getElementById('pendingCount').textContent = pending;
  document.getElementById('completedCount').textContent = completed;
}

// ===== FILTER APPOINTMENTS =====
function filterAppointments() {
  const searchTerm = document.getElementById('searchInput').value.toLowerCase();
  const statusFilter = document.getElementById('statusFilter').value;
  
  filteredAppointments = appointments.filter(appointment => {
    const matchesSearch = 
      appointment.patientName.toLowerCase().includes(searchTerm) ||
      appointment.phone.includes(searchTerm) ||
      appointment.reason.toLowerCase().includes(searchTerm);
    
    const matchesStatus = 
      statusFilter === 'all' || 
      appointment.status === statusFilter;
    
    return matchesSearch && matchesStatus;
  });
  
  loadAppointments();
  updateCounts();
}

// ===== VIEW PATIENT DETAILS =====
function viewPatientDetails(appointmentId) {
  const appointment = appointments.find(apt => apt.id === appointmentId);
  if (!appointment) return;
  
  currentAppointmentId = appointmentId;
  
  const modalBody = document.getElementById('modalBody');
  modalBody.innerHTML = `
    <div class="patient-detail-grid">
      <div class="detail-item">
        <label>Patient Name</label>
        <div class="value">${appointment.patientName}</div>
      </div>
      
      <div class="detail-item">
        <label>OP Number</label>
        <div class="value">${appointment.opNumber}</div>
      </div>
      
      <div class="detail-item">
        <label>Age</label>
        <div class="value">${appointment.age} years</div>
      </div>
      
      <div class="detail-item">
        <label>Gender</label>
        <div class="value">${appointment.gender}</div>
      </div>
      
      <div class="detail-item">
        <label>Phone</label>
        <div class="value">${appointment.phone}</div>
      </div>
      
      <div class="detail-item">
        <label>Appointment Time</label>
        <div class="value">${appointment.time}</div>
      </div>
      
      <div class="detail-item" style="grid-column: 1 / -1;">
        <label>Reason for Visit</label>
        <div class="value">${appointment.reason}</div>
      </div>
      
      <div class="detail-item">
        <label>Status</label>
        <div class="value">
          <span class="status-badge ${appointment.status}">
            ${appointment.status.replace('-', ' ')}
          </span>
        </div>
      </div>
    </div>
  `;
  
  document.getElementById('patientModal').classList.add('active');
}

// ===== CLOSE PATIENT MODAL =====
function closePatientModal() {
  document.getElementById('patientModal').classList.remove('active');
  currentAppointmentId = null;
}

// ===== START CONSULTATION FROM MODAL =====
function startConsultationFromModal() {
  if (currentAppointmentId) {
    startConsultation(currentAppointmentId);
  }
}

// ===== START CONSULTATION =====
function startConsultation(appointmentId) {
  const appointment = appointments.find(apt => apt.id === appointmentId);
  if (!appointment) return;
  
  // Update status to "in-progress" if it's pending
  if (appointment.status === 'pending') {
    appointment.status = 'in-progress';
    
    // Show status change notification
    showNotification(`Appointment status changed to "In Progress"`, 'info');
    
    // Reload table to reflect status change
    filterAppointments();
  }
  
  // Store appointment ID for consultation page
  localStorage.setItem('currentAppointmentId', appointmentId);
  
  // Navigate to consultation page
  setTimeout(() => {
    window.location.href = `patient_consultation.html?id=${appointmentId}`;
  }, 500);
}

// ===== CHANGE STATUS =====
function changeStatus(appointmentId) {
  const appointment = appointments.find(apt => apt.id === appointmentId);
  if (!appointment) return;
  
  currentAppointmentId = appointmentId;
  
  document.getElementById('statusPatientName').textContent = appointment.patientName;
  document.getElementById('currentStatus').innerHTML = `
    <span class="status-badge ${appointment.status}">
      ${appointment.status.replace('-', ' ')}
    </span>
  `;
  document.getElementById('newStatus').value = appointment.status;
  document.getElementById('statusRemarks').value = '';
  
  document.getElementById('statusModal').classList.add('active');
}

// ===== CLOSE STATUS MODAL =====
function closeStatusModal() {
  document.getElementById('statusModal').classList.remove('active');
  currentAppointmentId = null;
}

// ===== CONFIRM STATUS CHANGE =====
function confirmStatusChange() {
  if (!currentAppointmentId) return;
  
  const appointment = appointments.find(apt => apt.id === currentAppointmentId);
  if (!appointment) return;
  
  const newStatus = document.getElementById('newStatus').value;
  const remarks = document.getElementById('statusRemarks').value;
  
  // Update status
  appointment.status = newStatus;
  
  // Close modal
  closeStatusModal();
  
  // Reload table
  filterAppointments();
  
  // Show success message
  let message = `Status updated successfully!\n\nPatient: ${appointment.patientName}\nNew Status: ${newStatus.replace('-', ' ').toUpperCase()}`;
  if (remarks) {
    message += `\nRemarks: ${remarks}`;
  }
  alert(message);
}

// ===== REFRESH APPOINTMENTS =====
function refreshAppointments() {
  // Reset filters
  document.getElementById('searchInput').value = '';
  document.getElementById('statusFilter').value = 'all';
  
  // Reload
  filteredAppointments = [...appointments];
  loadAppointments();
  updateCounts();
  
  // Show feedback
  alert('✓ Appointments refreshed successfully!');
}

// ===== EXPORT TO EXCEL =====
function exportToExcel() {
  // Create CSV content (Excel can open CSV files)
  let csvContent = "data:text/csv;charset=utf-8,";
  
  // Add headers
  const headers = ["Time", "Patient Name", "Age", "Gender", "Phone", "Reason for Visit", "Status"];
  csvContent += headers.join(",") + "\n";
  
  // Add data rows
  filteredAppointments.forEach(appointment => {
    const row = [
      appointment.time,
      `"${appointment.patientName}"`, // Quotes to handle names with commas
      appointment.age,
      appointment.gender,
      appointment.phone,
      `"${appointment.reason}"`, // Quotes to handle reasons with commas
      appointment.status.replace('-', ' ').toUpperCase()
    ];
    csvContent += row.join(",") + "\n";
  });
  
  // Create download link
  const encodedUri = encodeURI(csvContent);
  const link = document.createElement("a");
  link.setAttribute("href", encodedUri);
  
  // Generate filename with current date
  const today = new Date();
  const dateStr = today.toISOString().split('T')[0]; // YYYY-MM-DD
  link.setAttribute("download", `appointments_${dateStr}.csv`);
  
  // Trigger download
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  
  // Show success notification
  showNotification(`Exported ${filteredAppointments.length} appointments to Excel!`, 'success');
}

// ===== LOGOUT =====
function logout() {
  if (confirm('Are you sure you want to logout?')) {
    location.href = 'doctor_portal.html';
  }
}

// ===== SHOW NOTIFICATION =====
function showNotification(message, type = 'success') {
  const notification = document.createElement('div');
  notification.className = `notification ${type}`;
  notification.textContent = message;
  document.body.appendChild(notification);
  
  setTimeout(() => {
    notification.classList.add('show');
  }, 100);
  
  setTimeout(() => {
    notification.classList.remove('show');
    setTimeout(() => {
      notification.remove();
    }, 300);
  }, 3000);
}

// ===== CHECK FOR COMPLETED APPOINTMENT =====
window.addEventListener('load', function() {
  // Handle completed appointment
  const completedId = localStorage.getItem('completedAppointmentId');
  if (completedId) {
    localStorage.removeItem('completedAppointmentId');
    
    // Update appointment status
    const appointment = appointments.find(apt => apt.id === completedId);
    if (appointment) {
      appointment.status = 'completed';
      filterAppointments();
      showNotification(`Appointment for ${appointment.patientName} marked as completed!`, 'success');
    }
  }
  
  // Handle draft appointment (revert to pending)
  const draftId = localStorage.getItem('draftAppointmentId');
  if (draftId) {
    localStorage.removeItem('draftAppointmentId');
    
    // Update appointment status back to pending
    const appointment = appointments.find(apt => apt.id === draftId);
    if (appointment && appointment.status === 'in-progress') {
      appointment.status = 'pending';
      filterAppointments();
      showNotification(`Draft saved for ${appointment.patientName}. Status reverted to Pending.`, 'info');
    }
  }
});

// ===== CLOSE MODALS ON OUTSIDE CLICK =====
window.onclick = function(event) {
  const patientModal = document.getElementById('patientModal');
  const statusModal = document.getElementById('statusModal');
  
  if (event.target === patientModal) {
    closePatientModal();
  }
  
  if (event.target === statusModal) {
    closeStatusModal();
  }
}
